
const LoadingScreen = () => (
  <div id="loading">
    <div className="loader"></div>
    <div className="loading-text">Memuat Data...</div>
  </div>
);
export default LoadingScreen;
