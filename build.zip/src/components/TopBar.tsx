
const TopBar = () => (
  <div className="top-bar">
    <i className="fas fa-shipping-fast"></i>
    Fitur Pelacakan Pengiriman Mobile Booking Azko
  </div>
);
export default TopBar;